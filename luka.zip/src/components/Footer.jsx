import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-[#0b143d] text-white py-16 px-4 md:px-12 font-sans relative">
      
      {/* Floating "Refer and Earn" Tab (Left Side) */}
      <div className="fixed left-0 top-1/2 -translate-y-1/2 z-40 hidden lg:block">
        {/* <div className="bg-black text-white px-3 py-6 rounded-r-lg cursor-pointer hover:bg-gray-900 transition-all shadow-lg" 
             style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>
          <span className="text-xs font-bold tracking-[0.2em] uppercase">Refer and Earn</span>
        </div> */}
      </div>

      <div className="max-w-7xl mx-auto">
        {/* Main Footer Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Column 1: Quick Links */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold tracking-tight">Quick Links</h3>
            <ul className="space-y-4 text-gray-300 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
            </ul>
          </div>

          {/* Column 2: Categories */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold tracking-tight">Categories</h3>
            <ul className="space-y-4 text-gray-300 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Laundry Pods</a></li>
              <li><a href="#" className="hover:text-white transition-colors">All products</a></li>
            </ul>
          </div>

          {/* Column 3: Policies */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold tracking-tight">Policies</h3>
            <ul className="space-y-4 text-gray-300 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Refund Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms and Conditions</a></li>
            </ul>
          </div>

          {/* Column 4: Newsletter Subscription */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold tracking-tight">Subscribe to our emails</h3>
            <div className="relative max-w-sm">
              <input 
                type="email" 
                placeholder="Email" 
                className="w-full bg-transparent border border-white/30 rounded-full py-3 px-6 text-sm focus:outline-none focus:border-white transition-all pr-12"
              />
              <button className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:translate-x-1 transition-transform">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                </svg>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Social Icons & Copyright */}
        <div className="pt-12 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-8">
          
          {/* Social Icons */}
          <div className="flex items-center space-x-6">
            <a href="#" className="hover:text-blue-400 transition-colors">
              <i className="fab fa-facebook-f text-xl"></i> {/* FontAwesome icon placeholder */}
              {/* Or use SVG icons below */}
              <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
            </a>
            <a href="#" className="hover:text-pink-400 transition-colors">
              <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
            </a>
            <a href="#" className="hover:text-red-500 transition-colors">
              <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/></svg>
            </a>
          </div>

          {/* Copyright Text */}
          <div className="text-gray-400 text-xs tracking-wider text-center md:text-right">
            © 2026, Lukapods Cleaners Powered by Shopify
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;